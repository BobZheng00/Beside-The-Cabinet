---
license: cc-by-4.0
---
Eve, the voice Shino speaks with in English: a speaker of the VCTK corpus (CSTR, University of Edinburgh; CC BY 4.0), as Kyutai's Pocket TTS (CC BY 4.0) speaks them, reading Shino's everyday lines. 29 seconds, ending on a short pause: Pocket TTS copies the voice from it.
