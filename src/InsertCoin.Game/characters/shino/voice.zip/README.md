---
license: apache-2.0
---
Shino's own voice, built into Beside the Cabinet: made with Kokoro-82M (hexgrad, Apache-2.0), its voice af_bella, a synthetic voice and not a real person's. Twelve clips with their words: everyday, happy, sad and surprised.
