---
license: apache-2.0
---
Fumiriya's own voice, built into Beside the Cabinet: made with Kokoro-82M (hexgrad, Apache-2.0), its voice am_fenrir, a synthetic voice and not a real person's. Twelve clips with their words: everyday, happy, sad and surprised.
